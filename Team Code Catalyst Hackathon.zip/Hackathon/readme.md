Dear admin,
app.py is the main file to run the skeleton code. We have only developed the front end ui to give the overview of our vision. This product is not final and hence there will be many other changes.
Thankyou