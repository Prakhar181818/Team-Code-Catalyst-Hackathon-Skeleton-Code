from flask import Flask, render_template, redirect, url_for, request, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Needed for flashing messages

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        #add code to save the user info in a database
        username = request.form.get('username')
        password = request.form.get('password')
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        #verify the username and password with a database
        username = request.form.get('username')
        password = request.form.get('password')
        # If authentication succeeds, redirect to home
        flash('Login successful!', 'success')
        return redirect(url_for('home_page'))
    return render_template('login.html')

@app.route('/home_page')
def home_page():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
